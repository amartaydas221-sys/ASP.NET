﻿using System;
using System.Collections.Generic;

namespace HospitalManagement.Data.Entities;

public partial class Doctor
{
    public int Id { get; set; }

    public string FullName { get; set; } = null!;

    public string Specialization { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string Phone { get; set; } = null!;

    public string LicenseNumber { get; set; } = null!;

    public int DepartmentId { get; set; }

    public string AvailableDays { get; set; } = null!;

    public decimal ConsultationFee { get; set; }

    public bool IsActive { get; set; }

    public virtual ICollection<Appointment> Appointments { get; set; } = new List<Appointment>();

    public virtual Department Department { get; set; } = null!;

    public virtual ICollection<MedicalRecord> MedicalRecords { get; set; } = new List<MedicalRecord>();
}
