﻿using System;
using System.Collections.Generic;

namespace HospitalManagement.Data.Entities;

public partial class Department
{
    public int Id { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public string? HeadOfDepartment { get; set; }

    public string? Phone { get; set; }

    public virtual ICollection<Doctor> Doctors { get; set; } = new List<Doctor>();
}
