﻿using System;
using System.Collections.Generic;

namespace HospitalManagement.Data.Entities;

public partial class Bill
{
    public int Id { get; set; }

    public int PatientId { get; set; }

    public string InvoiceNumber { get; set; } = null!;

    public decimal TotalAmount { get; set; }

    public decimal PaidAmount { get; set; }

    public string PaymentStatus { get; set; } = null!;

    public string PaymentMethod { get; set; } = null!;

    public DateTime BillingDate { get; set; }

    public DateTime DueDate { get; set; }

    public string? Notes { get; set; }

    public virtual Patient Patient { get; set; } = null!;
}
