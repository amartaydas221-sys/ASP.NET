using Microsoft.EntityFrameworkCore;
using HospitalManagementSystem.Data;

var builder = WebApplication.CreateBuilder(args);

// 1. Fetch connection string matching the exact name from your appsettings.json
var connectionString = builder.Configuration.GetConnectionString("HospitalManagementDbContext")
    ?? throw new InvalidOperationException("Connection string 'HospitalManagementDbContext' not found in appsettings.json.");

// 2. Register Entity Framework DbContext with SQL Server
builder.Services.AddDbContext<HospitalDbContext>(options =>
    options.UseSqlServer(connectionString));

// 3. Add MVC Controllers and Views
builder.Services.AddControllersWithViews();

var app = builder.Build();

// 4. Configure HTTP request pipeline
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

// 5. Default Route (Home/Index)
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();