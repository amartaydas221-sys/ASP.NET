﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HospitalManagementSystem.Models
{
    public class Bill
    {
        public int Id { get; set; }

        [Required]
        public int PatientId { get; set; }
        public Patient? Patient { get; set; }

        [Required, StringLength(30), Display(Name = "Invoice No.")]
        public string InvoiceNumber { get; set; } = string.Empty;

        [Column(TypeName = "decimal(18,2)"), Display(Name = "Total ($)")]
        public decimal TotalAmount { get; set; }

        [Column(TypeName = "decimal(18,2)"), Display(Name = "Paid ($)")]
        public decimal PaidAmount { get; set; }

        [NotMapped]
        public decimal BalanceDue => TotalAmount - PaidAmount;

        [Required, StringLength(30)]
        public string PaymentStatus { get; set; } = "Pending";

        [StringLength(50)]
        public string PaymentMethod { get; set; } = "Cash";

        public DateTime BillingDate { get; set; } = DateTime.UtcNow;
        public DateTime DueDate { get; set; } = DateTime.UtcNow.AddDays(15);
        public string? Notes { get; set; }
    }
}