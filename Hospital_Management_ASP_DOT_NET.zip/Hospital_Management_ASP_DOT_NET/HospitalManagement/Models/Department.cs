﻿using System.ComponentModel.DataAnnotations;

namespace HospitalManagementSystem.Models
{
    public class Department
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Department Name is required.")]
        [StringLength(100)]
        [Display(Name = "Department Name")]
        public string Name { get; set; } = string.Empty;

        [StringLength(500)]
        public string? Description { get; set; }

        [StringLength(100)]
        [Display(Name = "Head of Department")]
        public string? HeadOfDepartment { get; set; }

        [Phone, StringLength(20)]
        public string? Phone { get; set; }

        public ICollection<Doctor> Doctors { get; set; } = new List<Doctor>();
    }
}