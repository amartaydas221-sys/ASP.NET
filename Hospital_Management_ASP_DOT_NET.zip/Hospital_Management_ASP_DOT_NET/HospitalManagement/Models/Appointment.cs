﻿using System.ComponentModel.DataAnnotations;

namespace HospitalManagementSystem.Models
{
    public class Appointment
    {
        public int Id { get; set; }

        [Required, Display(Name = "Patient")]
        public int PatientId { get; set; }
        public Patient? Patient { get; set; }

        [Required, Display(Name = "Doctor")]
        public int DoctorId { get; set; }
        public Doctor? Doctor { get; set; }

        [Required, Display(Name = "Date & Time")]
        public DateTime AppointmentDateTime { get; set; }

        [Required, StringLength(200)]
        public string Reason { get; set; } = string.Empty;

        [Required, StringLength(30)]
        public string Status { get; set; } = "Scheduled";

        [StringLength(500)]
        public string? Notes { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}