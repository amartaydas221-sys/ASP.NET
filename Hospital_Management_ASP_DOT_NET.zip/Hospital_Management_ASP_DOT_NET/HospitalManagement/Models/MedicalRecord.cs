﻿using System.ComponentModel.DataAnnotations;

namespace HospitalManagementSystem.Models
{
    public class MedicalRecord
    {
        public int Id { get; set; }

        [Required]
        public int PatientId { get; set; }
        public Patient? Patient { get; set; }

        [Required]
        public int DoctorId { get; set; }
        public Doctor? Doctor { get; set; }

        [Required, Display(Name = "Visit Date")]
        public DateTime VisitDate { get; set; } = DateTime.UtcNow;

        [Required, StringLength(500)]
        public string Symptoms { get; set; } = string.Empty;

        [Required, StringLength(500)]
        public string Diagnosis { get; set; } = string.Empty;

        [Required, StringLength(1000), Display(Name = "Prescription")]
        public string PrescribedMedications { get; set; } = string.Empty;

        [StringLength(1000)]
        public string? TreatmentPlan { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}