﻿using System.ComponentModel.DataAnnotations;

namespace HospitalManagementSystem.Models
{
    public class Patient
    {
        public int Id { get; set; }

        [Required, StringLength(100), Display(Name = "Patient Full Name")]
        public string FullName { get; set; } = string.Empty;

        [Required, DataType(DataType.Date), Display(Name = "Date of Birth")]
        public DateTime DateOfBirth { get; set; }

        [Required, StringLength(20)]
        public string Gender { get; set; } = "Male";

        [Required, StringLength(10), Display(Name = "Blood Group")]
        public string BloodGroup { get; set; } = "O+";

        [Required, Phone, StringLength(20)]
        public string Phone { get; set; } = string.Empty;

        [EmailAddress, StringLength(100)]
        public string? Email { get; set; }

        [StringLength(250)]
        public string? Address { get; set; }

        [StringLength(100), Display(Name = "Emergency Contact Person")]
        public string? EmergencyContactName { get; set; }

        [Phone, StringLength(20), Display(Name = "Emergency Contact Phone")]
        public string? EmergencyContactPhone { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public ICollection<Appointment> Appointments { get; set; } = new List<Appointment>();
        public ICollection<MedicalRecord> MedicalRecords { get; set; } = new List<MedicalRecord>();
        public ICollection<Bill> Bills { get; set; } = new List<Bill>();
    }
}