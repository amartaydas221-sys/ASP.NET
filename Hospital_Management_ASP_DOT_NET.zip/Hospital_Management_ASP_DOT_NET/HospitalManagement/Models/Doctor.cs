﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace HospitalManagementSystem.Models
{
    public class Doctor
    {
        public int Id { get; set; }

        [Required, StringLength(100), Display(Name = "Doctor Name")]
        public string FullName { get; set; } = string.Empty;

        [Required, StringLength(100)]
        public string Specialization { get; set; } = string.Empty;

        [Required, EmailAddress, StringLength(100)]
        public string Email { get; set; } = string.Empty;

        [Required, Phone, StringLength(20)]
        public string Phone { get; set; } = string.Empty;

        [Required, StringLength(50), Display(Name = "Medical License No.")]
        public string LicenseNumber { get; set; } = string.Empty;

        [Display(Name = "Department")]
        public int DepartmentId { get; set; }
        public Department? Department { get; set; }

        [StringLength(100), Display(Name = "Visiting Hours")]
        public string AvailableDays { get; set; } = "Mon - Fri, 9:00 AM - 5:00 PM";

        [Column(TypeName = "decimal(18,2)"), Display(Name = "Consultation Fee ($)")]
        public decimal ConsultationFee { get; set; } = 50.00m;

        public bool IsActive { get; set; } = true;

        public ICollection<Appointment> Appointments { get; set; } = new List<Appointment>();
        public ICollection<MedicalRecord> MedicalRecords { get; set; } = new List<MedicalRecord>();
    }
}