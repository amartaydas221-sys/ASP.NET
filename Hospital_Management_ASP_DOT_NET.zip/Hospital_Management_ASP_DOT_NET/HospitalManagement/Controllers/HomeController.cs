using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HospitalManagementSystem.Data;
using HospitalManagementSystem.Models;
using HospitalManagementSystem.Models.ViewModels;

namespace HospitalManagementSystem.Controllers
{
    public class HomeController : Controller
    {
        private readonly HospitalDbContext _context;

        public HomeController(HospitalDbContext context)
        {
            _context = context;
        }

        // GET: /Home/Index
        public IActionResult Index()
        {
            var today = DateTime.UtcNow.Date;

            var viewModel = new DashboardViewModel
            {
                TotalPatients = _context.Patients.Count(),
                TotalDoctors = _context.Doctors.Count(d => d.IsActive),
                TotalAppointments = _context.Appointments.Count(),
                TodayAppointmentsCount = _context.Appointments
                    .Count(a => a.AppointmentDateTime.Date == today),
                TotalRevenue = _context.Bills.Sum(b => (decimal?)b.PaidAmount) ?? 0,
                PendingRevenue = _context.Bills
                    .Where(b => b.PaymentStatus != "Paid")
                    .Sum(b => (decimal?)(b.TotalAmount - b.PaidAmount)) ?? 0,

                UpcomingAppointments = _context.Appointments
                    .Include(a => a.Patient)
                    .Include(a => a.Doctor)
                    .OrderByDescending(a => a.AppointmentDateTime)
                    .Take(5)
                    .ToList(),

                RecentPatients = _context.Patients
                    .OrderByDescending(p => p.CreatedAt)
                    .Take(5)
                    .ToList(),

                RecentInvoices = _context.Bills
                    .Include(b => b.Patient)
                    .OrderByDescending(b => b.BillingDate)
                    .Take(5)
                    .ToList()
            };

            return View(viewModel);
        }

        public IActionResult Privacy() => View();

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}