﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HospitalManagementSystem.Data;
using HospitalManagementSystem.Models;

namespace HospitalManagementSystem.Controllers
{
    public class DepartmentsController : Controller
    {
        private readonly HospitalDbContext _context;

        public DepartmentsController(HospitalDbContext context)
        {
            _context = context;
        }

        // GET: /Departments
        public IActionResult Index()
        {
            var departments = _context.Departments
                .Include(d => d.Doctors)
                .OrderBy(d => d.Name)
                .ToList();

            return View(departments);
        }

        // GET: /Departments/Details/5
        public IActionResult Details(int? id)
        {
            if (id == null) return NotFound();

            var department = _context.Departments
                .Include(d => d.Doctors)
                .FirstOrDefault(m => m.Id == id);

            if (department == null) return NotFound();

            return View(department);
        }

        // GET: /Departments/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Departments/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Department department)
        {
            if (ModelState.IsValid)
            {
                _context.Add(department);
                _context.SaveChanges();
                TempData["Success"] = "Department added successfully!";
                return RedirectToAction(nameof(Index));
            }
            return View(department);
        }

        // GET: /Departments/Edit/5
        public IActionResult Edit(int? id)
        {
            if (id == null) return NotFound();

            var department = _context.Departments.Find(id);
            if (department == null) return NotFound();

            return View(department);
        }

        // POST: /Departments/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Department department)
        {
            if (id != department.Id) return NotFound();

            if (ModelState.IsValid)
            {
                _context.Update(department);
                _context.SaveChanges();
                TempData["Success"] = "Department updated successfully!";
                return RedirectToAction(nameof(Index));
            }
            return View(department);
        }

        // GET: /Departments/Delete/5
        public IActionResult Delete(int? id)
        {
            if (id == null) return NotFound();

            var department = _context.Departments
                .Include(d => d.Doctors)
                .FirstOrDefault(m => m.Id == id);

            if (department == null) return NotFound();

            return View(department);
        }

        // POST: /Departments/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var department = _context.Departments.Find(id);
            if (department != null)
            {
                _context.Departments.Remove(department);
                _context.SaveChanges();
                TempData["Success"] = "Department removed successfully!";
            }
            return RedirectToAction(nameof(Index));
        }
    }
}