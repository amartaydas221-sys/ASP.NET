﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HospitalManagementSystem.Data;
using HospitalManagementSystem.Models;

namespace HospitalManagementSystem.Controllers
{
    public class DoctorsController : Controller
    {
        private readonly HospitalDbContext _context;

        public DoctorsController(HospitalDbContext context)
        {
            _context = context;
        }

        // GET: /Doctors
        public IActionResult Index()
        {
            var doctors = _context.Doctors
                .Include(d => d.Department)
                .OrderBy(d => d.FullName)
                .ToList();

            return View(doctors);
        }

        // GET: /Doctors/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: /Doctors/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Doctor doctor)
        {
            if (ModelState.IsValid)
            {
                _context.Add(doctor);
                _context.SaveChanges();
                TempData["Success"] = "Doctor registered successfully!";
                return RedirectToAction(nameof(Index));
            }
            return View(doctor);
        }
    }
}