﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HospitalManagementSystem.Data;
using HospitalManagementSystem.Models;

namespace HospitalManagementSystem.Controllers
{
    public class AppointmentsController : Controller
    {
        private readonly HospitalDbContext _context;

        public AppointmentsController(HospitalDbContext context)
        {
            _context = context;
        }

        // 1. Index (Synchronous)
        public IActionResult Index(string? status)
        {
            var query = _context.Appointments
                .Include(a => a.Doctor)
                .Include(a => a.Patient)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(status))
            {
                query = query.Where(a => a.Status == status);
            }

            ViewBag.CurrentStatus = status;
            return View(query.OrderByDescending(a => a.AppointmentDateTime).ToList());
        }

        // 2. Create GET (Synchronous)
        public IActionResult Create()
        {
            ViewBag.DoctorId = new SelectList(_context.Doctors.Where(d => d.IsActive).ToList(), "Id", "FullName");
            ViewBag.PatientId = new SelectList(_context.Patients.ToList(), "Id", "FullName");

            var model = new Appointment
            {
                AppointmentDateTime = DateTime.Now.AddDays(1)
            };
            return View(model);
        }

        // 3. Create POST (Synchronous)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Appointment appointment)
        {
            if (ModelState.IsValid)
            {
                appointment.CreatedAt = DateTime.UtcNow;
                _context.Add(appointment);
                _context.SaveChanges();
                TempData["Success"] = "Appointment scheduled successfully!";
                return RedirectToAction(nameof(Index));
            }

            ViewBag.DoctorId = new SelectList(_context.Doctors.Where(d => d.IsActive).ToList(), "Id", "FullName", appointment.DoctorId);
            ViewBag.PatientId = new SelectList(_context.Patients.ToList(), "Id", "FullName", appointment.PatientId);
            return View(appointment);
        }

        // 4. Details (Synchronous)
        public IActionResult Details(int? id)
        {
            if (id == null) return NotFound();

            var appointment = _context.Appointments
                .Include(a => a.Doctor).ThenInclude(d => d.Department)
                .Include(a => a.Patient)
                .FirstOrDefault(m => m.Id == id);

            if (appointment == null) return NotFound();
            return View(appointment);
        }

        // 5. UpdateStatus (Synchronous)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult UpdateStatus(int id, string status)
        {
            var appointment = _context.Appointments.Find(id);
            if (appointment != null)
            {
                appointment.Status = status;
                _context.SaveChanges();
                TempData["Success"] = $"Status updated to '{status}'.";
            }
            return RedirectToAction(nameof(Index));
        }
    }
}