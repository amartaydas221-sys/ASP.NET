﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HospitalManagementSystem.Data;
using HospitalManagementSystem.Models;

namespace HospitalManagementSystem.Controllers
{
    public class MedicalRecordsController : Controller
    {
        private readonly HospitalDbContext _context;

        public MedicalRecordsController(HospitalDbContext context)
        {
            _context = context;
        }

        // GET: /MedicalRecords
        public IActionResult Index()
        {
            var records = _context.MedicalRecords
                .Include(m => m.Patient)
                .Include(m => m.Doctor)
                .OrderByDescending(m => m.VisitDate)
                .ToList();

            return View(records);
        }

        // GET: /MedicalRecords/Details/5
        public IActionResult Details(int? id)
        {
            if (id == null) return NotFound();

            var record = _context.MedicalRecords
                .Include(m => m.Patient)
                .Include(m => m.Doctor)
                .FirstOrDefault(m => m.Id == id);

            if (record == null) return NotFound();

            return View(record);
        }

        // GET: /MedicalRecords/Create
        public IActionResult Create(int? patientId)
        {
            ViewBag.PatientId = new SelectList(_context.Patients.OrderBy(p => p.FullName).ToList(), "Id", "FullName", patientId);
            ViewBag.DoctorId = new SelectList(_context.Doctors.Where(d => d.IsActive).OrderBy(d => d.FullName).ToList(), "Id", "FullName");

            var model = new MedicalRecord
            {
                PatientId = patientId ?? 0,
                VisitDate = DateTime.Now
            };

            return View(model);
        }

        // POST: /MedicalRecords/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(MedicalRecord medicalRecord)
        {
            if (ModelState.IsValid)
            {
                medicalRecord.CreatedAt = DateTime.UtcNow;
                _context.Add(medicalRecord);
                _context.SaveChanges();
                TempData["Success"] = "Medical record & prescription created successfully!";
                return RedirectToAction(nameof(Index));
            }

            ViewBag.PatientId = new SelectList(_context.Patients.OrderBy(p => p.FullName).ToList(), "Id", "FullName", medicalRecord.PatientId);
            ViewBag.DoctorId = new SelectList(_context.Doctors.Where(d => d.IsActive).OrderBy(d => d.FullName).ToList(), "Id", "FullName", medicalRecord.DoctorId);
            return View(medicalRecord);
        }
    }
}