﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using HospitalManagementSystem.Data;
using HospitalManagementSystem.Models;

namespace HospitalManagementSystem.Controllers
{
    public class PatientsController : Controller
    {
        private readonly HospitalDbContext _context;

        public PatientsController(HospitalDbContext context)
        {
            _context = context;
        }

        // GET: /Patients
        public IActionResult Index(string? search, string? bloodGroup)
        {
            var query = _context.Patients.AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                query = query.Where(p => p.FullName.Contains(search) || p.Phone.Contains(search));
            }

            if (!string.IsNullOrWhiteSpace(bloodGroup))
            {
                query = query.Where(p => p.BloodGroup == bloodGroup);
            }

            ViewBag.CurrentSearch = search;
            ViewBag.CurrentBloodGroup = bloodGroup;

            return View(query.OrderByDescending(p => p.CreatedAt).ToList());
        }

        // GET: /Patients/Details/5
        public IActionResult Details(int? id)
        {
            if (id == null) return NotFound();

            var patient = _context.Patients
                .Include(p => p.Appointments).ThenInclude(a => a.Doctor)
                .Include(p => p.MedicalRecords).ThenInclude(m => m.Doctor)
                .Include(p => p.Bills)
                .FirstOrDefault(m => m.Id == id);

            if (patient == null) return NotFound();
            return View(patient);
        }

        // GET: /Patients/Create
        public IActionResult Create() => View();

        // POST: /Patients/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Patient patient)
        {
            if (ModelState.IsValid)
            {
                patient.CreatedAt = DateTime.UtcNow;
                _context.Add(patient);
                _context.SaveChanges();
                TempData["Success"] = "Patient registered successfully!";
                return RedirectToAction(nameof(Index));
            }
            return View(patient);
        }

        // GET: /Patients/Edit/5
        public IActionResult Edit(int? id)
        {
            if (id == null) return NotFound();
            var patient = _context.Patients.Find(id);
            if (patient == null) return NotFound();
            return View(patient);
        }

        // POST: /Patients/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Patient patient)
        {
            if (id != patient.Id) return NotFound();

            if (ModelState.IsValid)
            {
                _context.Update(patient);
                _context.SaveChanges();
                TempData["Success"] = "Patient updated successfully!";
                return RedirectToAction(nameof(Index));
            }
            return View(patient);
        }

        // GET: /Patients/Delete/5
        public IActionResult Delete(int? id)
        {
            if (id == null) return NotFound();
            var patient = _context.Patients.Find(id);
            if (patient == null) return NotFound();
            return View(patient);
        }

        // POST: /Patients/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var patient = _context.Patients.Find(id);
            if (patient != null)
            {
                _context.Patients.Remove(patient);
                _context.SaveChanges();
                TempData["Success"] = "Patient deleted successfully!";
            }
            return RedirectToAction(nameof(Index));
        }
    }
}