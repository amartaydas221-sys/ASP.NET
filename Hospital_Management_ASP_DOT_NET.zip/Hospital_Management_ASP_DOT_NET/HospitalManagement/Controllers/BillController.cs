﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using HospitalManagementSystem.Data;
using HospitalManagementSystem.Models;

namespace HospitalManagementSystem.Controllers
{
    public class BillsController : Controller
    {
        private readonly HospitalDbContext _context;

        public BillsController(HospitalDbContext context)
        {
            _context = context;
        }

        // GET: /Bills
        public IActionResult Index()
        {
            var bills = _context.Bills
                .Include(b => b.Patient)
                .OrderByDescending(b => b.BillingDate)
                .ToList();

            return View(bills);
        }

        // GET: /Bills/Details/5
        public IActionResult Details(int? id)
        {
            if (id == null) return NotFound();

            var bill = _context.Bills
                .Include(b => b.Patient)
                .FirstOrDefault(m => m.Id == id);

            if (bill == null) return NotFound();

            return View(bill);
        }

        // GET: /Bills/Create
        public IActionResult Create(int? patientId)
        {
            ViewBag.PatientId = new SelectList(_context.Patients.OrderBy(p => p.FullName).ToList(), "Id", "FullName", patientId);

            var randomNum = new Random().Next(100, 999);
            var model = new Bill
            {
                PatientId = patientId ?? 0,
                InvoiceNumber = $"INV-{DateTime.Now:yyyy}-{randomNum}",
                BillingDate = DateTime.Now,
                DueDate = DateTime.Now.AddDays(15),
                PaymentStatus = "Pending",
                PaymentMethod = "Cash",
                TotalAmount = 500.00m,
                PaidAmount = 0.00m
            };

            return View(model);
        }

        // POST: /Bills/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Bill bill)
        {
            if (ModelState.IsValid)
            {
                // Auto calculate status
                if (bill.PaidAmount >= bill.TotalAmount && bill.TotalAmount > 0)
                {
                    bill.PaymentStatus = "Paid";
                }
                else if (bill.PaidAmount > 0 && bill.PaidAmount < bill.TotalAmount)
                {
                    bill.PaymentStatus = "PartiallyPaid";
                }
                else
                {
                    bill.PaymentStatus = "Pending";
                }

                _context.Add(bill);
                _context.SaveChanges();
                TempData["Success"] = "Invoice created successfully!";
                return RedirectToAction(nameof(Index));
            }

            ViewBag.PatientId = new SelectList(_context.Patients.OrderBy(p => p.FullName).ToList(), "Id", "FullName", bill.PatientId);
            return View(bill);
        }
    }
}