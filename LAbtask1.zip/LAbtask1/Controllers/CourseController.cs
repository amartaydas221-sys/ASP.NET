﻿using Microsoft.AspNetCore.Mvc;

namespace FirstMVCApp.Controllers
{
    [Route("courses")]
    public class CourseController : Controller
    {
        // URL: /courses
        [Route("")]
        public IActionResult Index()
        {
            ViewBag.Title = "All Courses";

            return View();
        }

        // URL: /courses/details/5
        [Route("details/{id:int}")]
        public IActionResult Details(int id)
        {
            ViewBag.CourseId = id;

            return View();
        }

        // URL: /courses/search?keyword=mvc
        [Route("search")]
        public IActionResult Search(string keyword)
        {
            ViewBag.Keyword = keyword;

            return View();
        }
    }
}