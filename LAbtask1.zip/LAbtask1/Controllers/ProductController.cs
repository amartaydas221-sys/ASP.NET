﻿using Microsoft.AspNetCore.Mvc;

namespace LAbtask1.Controllers
{
    public class ProductController : Controller
    {
        public IActionResult Index(string category, int id)

        {
            ViewBag.category = category;
            ViewBag.id = id;
            return View();
        }
    }
}
