﻿using Microsoft.AspNetCore.Mvc;
using SQLCONNECTION.Data;
using SQLCONNECTION.Data.Entities;

namespace SQLCONNECTION.Controllers
{
    public class DepartmentController: Controller
    {
        private readonly FirstConnectionDbContext _context;
        public DepartmentController(FirstConnectionDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {   
            var department= _context.Departments.ToList();
            return View(department );
        }
        public IActionResult Delete(int did)
        {
            var dept = _context.Departments.Find(did);

            if (dept == null)
            {
                TempData["Error"] = "Department not found. ID: " + did;
            }
            else
            {
                _context.Departments.Remove(dept);
                _context.SaveChanges();

                TempData["Success"] = "Department deleted successfully";
            }

            return RedirectToAction("Index");
        }
        
        [HttpGet]
        public IActionResult Create()
        {
            return View(new Department());
        }
        [HttpPost]
        public IActionResult Create(Department dept)
        { 
            if(ModelState.IsValid == false)
            {
                return View(dept);
            }
            _context.Departments.Add(dept); 
            _context.SaveChanges();
            TempData["Success"] = "Department created successfully";    
            return RedirectToAction("Index");   
        }

        [HttpGet]
        public IActionResult Edit(int did)
        {
            var dept = _context.Departments.Find(did);
            
            return View(dept);
        }
        [HttpPost]
        public IActionResult Edit(Department dept)
        {
            if (ModelState.IsValid == false)
            {
                return View(dept);
            }
            _context.Departments.Update(dept);
            _context.SaveChanges();
            TempData["Success"] = "Department updated successfully";
            return RedirectToAction("Index");
        }

    }
}
