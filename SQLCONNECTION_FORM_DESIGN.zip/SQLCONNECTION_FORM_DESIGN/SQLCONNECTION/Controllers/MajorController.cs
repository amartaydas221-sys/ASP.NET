﻿using Microsoft.AspNetCore.Mvc;
using SQLCONNECTION.Data;

namespace SQLCONNECTION.Controllers
{
    public class MajorController : Controller
    {
        private readonly FirstConnectionDbContext _context;
        public MajorController(FirstConnectionDbContext context)
        {
            _context = context;
        }   
        public IActionResult Index()
        {
            var major = _context.Majors.ToList();
            return View(major);
        }
    }
}
