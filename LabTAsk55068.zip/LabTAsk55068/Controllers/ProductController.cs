﻿using LabTAsk55068.Models; 
using Microsoft.AspNetCore.Mvc;

public class ProductController : Controller
{

    [HttpGet]
    public IActionResult Index()
    {
        return View();
    }


    [HttpPost]
   
    public IActionResult Index(ProductModel model) 
    {
        if (ModelState.IsValid)
        {
            return View();
        }

        return View(model); 
    }
}

