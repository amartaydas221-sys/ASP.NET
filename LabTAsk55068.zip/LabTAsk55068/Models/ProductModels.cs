﻿using System;
using System.ComponentModel.DataAnnotations;

public class ProductModel
{
    [Required]
    [Display(Name = "Product Name")]
    public string ProductName { get; set; } = string.Empty;

    [Required]
    [Display(Name = "Price")]
    public decimal Price { get; set; }

    [Required]
    [Display(Name = "Stock Quantity")]
    public int StockQuantity { get; set; }
}